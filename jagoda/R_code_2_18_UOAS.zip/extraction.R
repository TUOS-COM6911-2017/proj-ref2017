setwd("/Users/gosc/Desktop/TEAM_PROJECT/UOA_MINE")
getwd()
install.packages("readxl")
install.packages("ggplot2")
install.packages("reshape2")

#Packages that will be needed (Data table, data melting, reshaping, ggplot2 for visualisation)
library(readxl)
library(data.table)
library(ggplot2)
library(plyr)
library(dplyr)
install.packages('DT')
library(DT)
library(reshape2)

#DATA SUBMISION
#Data  for REF and RAE for Economy and Econometrics (18;34)
ECON_RAE_OUTPUT<-read.csv("Econometrics_Economy/RA2.csv", header = TRUE, sep=',')
ECON_REF_OUTPUT<-read_excel(path="Econometrics_Economy/REF_Economics and_Econometrics.xlsx", sheet = "Outputs")
#Data for public health (6,7,8;2)
HEAL_RAE_OUTPUT_a<-read.csv("Public_health/Epidemiology_Public_Health/RA2.csv", header = TRUE, sep=',')
HEAL_RAE_OUTPUT_b<-read.csv("Public_health/Health_Services_Research/RA2.csv", header = TRUE, sep=',')
HEAL_RAE_OUTPUT_c<-read.csv("Public_health/Primary_Care_and_Other_Community_Based_Clinical_Subjects/RA2.csv", header = TRUE, sep=',')
HEAL_RAE_OUTPUT<-rbind(HEAL_RAE_OUTPUT_a,HEAL_RAE_OUTPUT_b,HEAL_RAE_OUTPUT_c)
rm(HEAL_RAE_OUTPUT_a,HEAL_RAE_OUTPUT_b,HEAL_RAE_OUTPUT_c)
HEAL_REF_OUTPUT<-read_excel(path="Public_health/REF_public_health.xlsx", sheet = "Outputs")


#RESULTS
ECON_REF_RESULTS<-read_excel(path="Econometrics_Economy/Results/uoa18.xlsx")
ECON_RAE_RESULTS<-read_excel(path="Econometrics_Economy/Results/uoa34.xls")

HEAL_REF_RESULTS<-read_excel(path="Public_health/Results/uoa2.xlsx")
HEAL_RAE_RESULTS_a<-read_excel(path="Public_health/Results/uoa06.xls")
HEAL_RAE_RESULTS_b<-read_excel(path="Public_health/Results/uoa07.xls")
HEAL_RAE_RESULTS_c<-read_excel(path="Public_health/Results/uoa08.xls")
HEAL_RAE_RESULTS<-rbind(HEAL_RAE_RESULTS_a,HEAL_RAE_RESULTS_b,HEAL_RAE_RESULTS_c)
rm(HEAL_RAE_RESULTS_a,HEAL_RAE_RESULTS_b,HEAL_RAE_RESULTS_c)

#DATA CLEANING - removing spaces in a colname
colnames(ECON_REF_OUTPUT) <- gsub(" ", "_", colnames(ECON_REF_OUTPUT))
colnames(HEAL_REF_OUTPUT) <- gsub(" ", "_", colnames(HEAL_REF_OUTPUT))

#changing names for results

colnames(ECON_REF_RESULTS) <- c('UKPRN','Inst_name','Inst_sort_order','Main_panel','UOA_nr','UOA_nam','Multi_letter','Multi_name','Joint_submission','Profile','FTE_cat_A','Four','Three','Two','One','Unclassified')
colnames(ECON_RAE_RESULTS) <- c('Inst_name','FTE_cat_A','Four','Three','Two','One','Unclassified','X2','HESA_INST_CODE','UOA_nr','Multi_letter')
colnames(HEAL_REF_RESULTS) <- c('UKPRN','Inst_name','Inst_sort_order','Main_panel','UOA_nr','UOA_nam','Multi_letter','Multi_name','Joint_submission','Profile','FTE_cat_A','Four','Three','Two','One','Unclassified')
colnames(HEAL_RAE_RESULTS) <- c('Inst_name','FTE_cat_A','Four','Three','Two','One','Unclassified','X2','HESA_INST_CODE','UOA_nr','Multi_letter')

#ECONOMETRICS - DATA CLEANING


colnames(ECON_REF_OUTPUT)
summary(ECON_REF_OUTPUT)
#removing na
ECON_REF_OUTPUT[is.na(ECON_REF_OUTPUT)] <- 0
ECON_REF_OUTPUT<-as.data.table(ECON_REF_OUTPUT)
#Number of Submisssion
#First argument - filter, second argument value(it can be a few operations at once eg. sum of few var);
#third argument - group by; fourth [] ordering (descending in that case)
ECON_SUMMARY_1<-ECON_REF_OUTPUT[,(number=.N),
                                by=c("Institution_name","Output_type")][order(-V1)]

ECON_SUMMARY_1$Institution_name<-as.factor(ECON_SUMMARY_1$Institution_name)
ECON_SUMMARY_1$Output_type<-as.factor(ECON_SUMMARY_1$Output_type)

summary(ECON_SUMMARY_1$Institution_name)
#Changing name of columns 
colnames(ECON_SUMMARY_1)<-c("Institution_name","Output_type","NrSub")


#Let's recode output (dict was taken from excel file called Output filled guide)
ECON_SUMMARY_1$Output_type<-revalue(ECON_SUMMARY_1$Output_type, c("A"="Authored book","B"="Edited book", "C"="Chapter in book",
  "R"="Scholarly edition","D"="Journal article","E"="Conference contribution","U"="Working paper",
  "L"="Artefact","P"="Devices and products","I"="Performance","M"="Exhibition","F"="Patent/published patent application",                                  
  "J"="Composition","K"="Design","N"="Research report for external body","O"="Confidential report (for external body)",
"G"="Software","H"="Website content","G"="Software","H"="Website content","Q"="Digital or visual media","T"="Other"))

#GGplot2 charts
#First we define ourdata x, y and color for our cohorts, then we adding with + all the features that we want
#Check the link: http://www.cookbook-r.com/Graphs/
ggplot(ECON_SUMMARY_1, aes(x = Institution_name, y=NrSub, fill = Output_type))+ 
  geom_bar(stat = "Identity")+theme_bw(base_size = 12) + theme(axis.text.x=element_text(angle=90,hjust=1)) +
  ggtitle("Number of submissions by output type")+theme(plot.title = element_text(hjust = 0.5))+xlab("Institution name")+ylab('Number of Submissions')+
  guides(fill=guide_legend(title="Output type"))

#Now I am preparing data tables for particular plots to see number of submissions per Institution
ECON_SUMMARY_1a<-ECON_REF_OUTPUT[,{n=.N
  .SD[,.(procent=.N/n), as.factor(Institution_name)]},][order(-procent)]

#To make a table looking nicer we use a DT library 
#(this strange part of code is just a json to make it looks better)
datatable(ECON_SUMMARY_1a, rownames=F,
          colnames=c('Institution','Share in Total Number of Submissions'),
          class='stripe', options=list(pageLength=50,initComplete = JS("
                                                         function(settings, json) {
                                                         $(this.api().table().header()).css({
                                                         'background-color': '#9e275a',
                                                         'color': '#fff'
                                                         });
                                                         }")))%>%
  formatPercentage('procent',2)



#brief look on results

ECON_REF_RESULTS<-as.data.table(ECON_REF_RESULTS)
ECON_REF_RESULTS_OVERALL<-ECON_REF_RESULTS[Profile=="Overall",.(Inst_name,Four,Three,Two,One,Unclassified),]
ECON_REF_RESULTS_OUTPUTS<-ECON_REF_RESULTS[Profile=="Outputs",.(Inst_name,Four,Three,Two,One,Unclassified),]

#melting data in order to present OVERALL RESULTS on a plot
#Search for help for function melt and reshape
ECON_REF_RES_OVERALL_MELTED<-melt(ECON_REF_RESULTS_OVERALL, id.vars = "Inst_name", measure.vars = c("Four","Three","Two","One","Unclassified"))
colnames(ECON_REF_RES_OVERALL_MELTED)<-c('Inst_name','NumOfStars','Percent')

ggplot(ECON_REF_RES_OVERALL_MELTED, aes(x = Inst_name, y=Percent, color = NumOfStars, fill=NumOfStars))+geom_bar(stat = "Identity")+theme_bw(base_size = 12) + 
  theme(axis.text.x=element_text(angle=90,hjust=1)) + ggtitle("Results by Institution")+theme(plot.title = element_text(hjust = 0.5))+
  xlab("Institution name")+ylab('%')

#melting outputs

ECON_REF_RES_OUTPUTS_MELTED<-melt(ECON_REF_RESULTS_OUTPUTS, id.vars = "Inst_name", measure.vars = c("Four","Three","Two","One","Unclassified"))
colnames(ECON_REF_RES_OUTPUTS_MELTED)<-c('Inst_name','NumOfStars','Percent')

#Further step - number of works wit given stars
#Independent number of good works
ECON_SUMMARY_1b<-ECON_REF_OUTPUT[,.N, as.factor(Institution_name)][order(-N)]
colnames(ECON_SUMMARY_1b)<-c('Inst_name','Number_Sub')
ECON_table_number_of_works<-merge(ECON_REF_RESULTS_OUTPUTS,ECON_SUMMARY_1b)
ECON_table_number_of_works<-ECON_table_number_of_works[,.(Four_n=round(Four/100*Number_Sub),
                                                          Three_n=round(Three/100*Number_Sub),
                                                          Two_n=round(Two/100*Number_Sub),
                                                          One_n=round(One/100*Number_Sub),
                                                          Uncl=round(Unclassified/100*Number_Sub))
                                                          ,Inst_name]
ECON_table_number_of_works[,':='(sum=Four_n+Three_n+Two_n+One_n+Uncl)]
#check<-merge(ECON_table_number_of_works,ECON_SUMMARY_1b)
#comaprison of charts ??
ECON_REF_RES_OUTPUTS_MELTED_NUMBER<-melt(ECON_table_number_of_works, id.vars = "Inst_name", measure.vars = c("Four_n","Three_n","Two_n","One_n","Uncl"))
colnames(ECON_REF_RES_OUTPUTS_MELTED_NUMBER)<-c('Inst_name','NumOfStars','Number')

#Creating two plots - submissons in % and num
g1<-ggplot(ECON_REF_RES_OUTPUTS_MELTED, aes(x = Inst_name, y=Percent, color = NumOfStars, fill=NumOfStars))+geom_bar(stat = "Identity")+theme_bw(base_size = 12) + 
  theme(axis.text.x=element_text(angle=90,hjust=1)) + ggtitle("Results by Institution in percents")+theme(plot.title = element_text(hjust = 0.5))+
  xlab("Institution name")+ylab('%')
g2<-ggplot(ECON_REF_RES_OUTPUTS_MELTED_NUMBER, aes(x =Inst_name, y=Number, color=NumOfStars, fill=NumOfStars))+geom_bar(stat = "Identity", position=position_dodge())+theme_bw(base_size = 12) + 
  theme(axis.text.x=element_text(angle=90,hjust=1)) + ggtitle("Results by Institution - number")+theme(plot.title = element_text(hjust = 0.5))+
  xlab("Institution name")+ylab('Number')


#This part of code was found at internet - it is just creating a function that put our plots at one sheet
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  plots <- c(list(...), plotlist)
  numPlots = length(plots)
  if (is.null(layout)) {
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    for (i in 1:numPlots) {
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}

#Creaing a plot
multiplot(g1,g2, cols=2)




############

##PART FROM THAT NEED IMPROVEMENTS - DON'T LOOK AT THAT NOW 
#further suggestions -> number of citation, number of additional autors
#preparing data sets for searching for a correlation

colnames(ECON_REF_OUTPUT)
#removing NA?
#ECON_REF_OUTPUT[, lapply(.SD, function(x) ifelse(is.na(x),0,x))]

ECON_SUMMARY_2<-ECON_REF_OUTPUT[,(number=.N),by=c("Institution_name","Year")][order(-V1)]
ggplot(ECON_SUMMARY_2, aes(x = Institution_name, y=V1, fill = Year))+ 
  geom_bar(stat = "Identity", position=position_dodge())+theme_bw(base_size = 12) + theme(axis.text.x=element_text(angle=90,hjust=1)) +
  ggtitle("Number of submissions per year")+theme(plot.title = element_text(hjust = 0.5))+xlab("Institution name")+ylab('Number of Submissions')+
  guides(fill=guide_legend(title="year"))
ggplot(ECON_SUMMARY_2, aes(x = Year, y=V1, fill= Institution_name))+ 
  geom_bar(stat = "Identity")+theme_bw(base_size = 12) + theme(axis.text.x=element_text(angle=90,hjust=1)) +
  ggtitle("Number of submissions by output type")+theme(plot.title = element_text(hjust = 0.5))+xlab("Institution name")+ylab('Number of Submissions')+
  guides(fill=guide_legend(title="Output type"))
 #?????????STH WRONG
#ECON_SUMMARY_2_casted<-dcast(ECON_SUMMARY_2, Institution_name~Year, mean)
#ECON_SUMMARY_2_casted<-ECON_SUMMARY_2_casted[, lapply(.SD, function(x) ifelse(is.na(x),0,x))]

## here I am changing all character var on factors (using lapply function and names of var)
ECON_REF_OUTPUT<-ECON_REF_OUTPUT[, lapply(.SD, function(x) as.factor(x)), 
   .SDcols = c('Institution_code_(UKPRN)','Institution_name','Main_panel','Unit_of_assessment_number',
               'Unit_of_assessment_name','Multiple_submission_letter','Multiple_submission_name','Joint_submission',
               'Output_type','Title','Place','Publisher','Volume_title','Volume','First_page', 'Article_number', 'ISBN',        
'ISSN', 'DOI',  'Patent_number','Year', 'URL',  'Number_of_additional_authors',
'Non-english','Interdisciplinary', 'Proposed_double-weighted','Research_group',  'Citations_applicable')]


#I wanted to search for correlation but it doesn't work
summary(ECON_REF_OUTPUT)
class(ECON_REF_OUTPUT)
install.packages("PerformanceAnalytics")
library(PerformanceAnalytics)
chart.Correlation(ECON_REF_OUTPUT)
